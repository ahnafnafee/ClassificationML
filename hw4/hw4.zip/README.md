# ClassificationML
 Implement Naive Bayes and Logistic Regression classifiers for the purpose of binary classification.

- Imported sklearn to test if my splitting was done correctly or not. No pre-made ML models were used for the actual implementation
- For LogReg, run the Jupyter Notebook file from the top so that it retains the necessary classes in memory.
- The math for Q1.2.c can be found in the source code. 
- And lastly, I give up 🙂